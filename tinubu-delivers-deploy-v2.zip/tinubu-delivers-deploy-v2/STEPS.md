# This replaces everything from before — those earlier files had wrong cache keys.

## In Codespaces, in your tinubu-delivers repo:

1. Replace your existing functions/claude.js with the one in this folder.
   (It's your real file with one block changed — the part that called the
   AI to generate content on a cache miss. Everything else is identical.)

2. Copy functions/seed.js and functions/seed-payload-v2.json into functions/.

3. In terminal:
   git add functions/
   git commit -m "Serve only verified content; remove live generation fallback"
   git push

4. Wait for Cloudflare Pages to finish deploying (Deployments tab in Cloudflare dashboard).

5. Visit: https://tinubu-delivers.pages.dev/seed?key=YOUR_SEED_KEY
   (same SEED_KEY you already set as an environment variable)

6. Confirm it says "seeded": 49, "failed": 0

7. Delete functions/seed.js and functions/seed-payload-v2.json:
   git rm functions/seed.js functions/seed-payload-v2.json
   git commit -m "Remove seed files after seeding"
   git push

8. Open the live site, click through a few sectors and a few states
   (try Lagos, try FCT Abuja) — you should see the verified content now,
   not AI-generated content.
