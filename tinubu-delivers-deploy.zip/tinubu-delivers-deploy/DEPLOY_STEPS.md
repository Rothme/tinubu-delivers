# Deploy steps — verified content go-live

## 0. Before anything else
Rotate the GitHub token, Anthropic API key, and Cloudflare API token that were pasted into
chat earlier. Do not deploy with the old ones.

## 1. Add files to your repo
Copy into `Rothme/tinubu-delivers`:
- `functions/seed.js`
- `functions/delivers-content.js`
- `functions/seed-payload.json`  (the 49 verified entries)

## 2. Set the seed key
In Cloudflare Pages dashboard -> your project -> Settings -> Environment variables,
add `SEED_KEY` = any random string you choose. This just stops strangers from re-triggering
the seed endpoint.

## 3. Point the frontend at the new read endpoint
In `delivers/index.html`, find wherever it currently calls the old generation endpoint
(likely `functions/claude.js`) and point those fetch calls at `/delivers-content?type=sector&slug=...`
or `/delivers-content?type=state&slug=...` instead. I don't have that file's current code, so
this step needs your hand or a follow-up message with the file pasted in — then I'll do it
as a precise patch instead of guessing at your existing fetch logic.

## 4. Deploy and seed
- Push to GitHub -> Cloudflare Pages auto-deploys.
- Visit `https://tinubu-delivers.pages.dev/seed?key=YOUR_SEED_KEY` ONCE.
- Confirm the JSON response shows `"seeded": 49, "failed": 0`.
- Delete `functions/seed.js` and `functions/seed-payload.json`, redeploy.
  (Keep a copy of seed-payload.json outside the repo if you'll need to reseed later —
  regenerate it any time from AUDIT_LOG.md's process instead of hand-editing.)

## 5. Spot-check the live site
Check `state:fct` (should show the "no data" message, not a number), `state:lagos`, and
`sector:economy-finance` against the reviewed Word doc your team marked up.

## 6. Old functions/claude.js
Once delivers-content.js is confirmed working, retire the old generation function entirely —
leaving it in place as a fallback would silently reintroduce the exact problem this rebuild fixes.
