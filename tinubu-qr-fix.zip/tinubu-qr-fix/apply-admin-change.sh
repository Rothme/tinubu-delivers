#!/bin/bash
# apply-admin-change.sh
# Patches admin/index.html in place: changes the showQR() QR text so it
# encodes a /track-qr redirect link instead of baking the destination in.
# Safe to run from the repo root in Codespaces.

set -e

FILE="admin/index.html"

if [ ! -f "$FILE" ]; then
  echo "ERROR: $FILE not found. Run this script from the repo root."
  exit 1
fi

if grep -q "track-qr?tag" "$FILE"; then
  echo "Already patched — no change needed."
  exit 0
fi

if ! grep -q "text: BASE_URL + '?ref=' + encodeURIComponent(refCode)," "$FILE"; then
  echo "ERROR: expected line not found in $FILE."
  echo "The file may have changed since this script was written."
  echo "Search admin/index.html for 'function showQR' and change the 'text:' line manually — see README.md."
  exit 1
fi

sed -i "s|text: BASE_URL + '?ref=' + encodeURIComponent(refCode),|text: location.origin + '/track-qr?tag=' + encodeURIComponent(refCode),|" "$FILE"

if grep -q "track-qr?tag" "$FILE"; then
  echo "SUCCESS: admin/index.html patched."
else
  echo "ERROR: patch did not apply. Check $FILE manually."
  exit 1
fi
