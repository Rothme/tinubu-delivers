# QR Destination Fix — Deploy Steps

This makes newly-generated QR codes future-proof: instead of baking the
destination URL directly into the printed code, codes now point at a
/track-qr redirect whose target lives in KV — so it can be changed later
without reprinting anything.

Already-printed codes are unaffected either way.

## What's in this zip
- `functions/track-qr.js` — full replacement file (safe to overwrite)
- `apply-admin-change.sh` — patches the one line in `admin/index.html` that needs to change

## Steps (run in Codespaces terminal, from the repo root)

**1. Upload this zip into Codespaces**
Drag `tinubu-qr-fix.zip` into the Codespaces file explorer (same as before).

**2. Unzip it**
```
unzip tinubu-qr-fix.zip -d /tmp/qrfix
```

**3. Copy the updated function into place**
```
cp /tmp/qrfix/tinubu-qr-fix/functions/track-qr.js functions/track-qr.js
```

**4. Patch admin/index.html**
```
chmod +x /tmp/qrfix/tinubu-qr-fix/apply-admin-change.sh
/tmp/qrfix/tinubu-qr-fix/apply-admin-change.sh
```
You should see `SUCCESS: admin/index.html patched.` If you see an ERROR instead,
stop and paste it back — don't proceed to step 5.

**5. Review what changed (optional but recommended)**
```
git diff
```

**6. Commit and push**
```
git add functions/track-qr.js admin/index.html
git commit -m "Decouple QR codes from destination URL via track-qr redirect"
git push
```

**7. Watch the deploy**
Cloudflare Pages dashboard → your project → Deployments tab → wait for green.

**8. Test live**
- Open the admin panel → click "QR Code" on any approved org
- Scan it with your phone → confirm it lands on `/delivers/`
- Check "QR Code Usage" in the admin panel → confirm the scan count went up by 1

## If you ever need to change where QR codes redirect to (later, not now)
Cloudflare dashboard → Workers & Pages → your project → KV → `TD_CACHE` →
add/edit key `qr:destination` → value = new path or full URL.
No redeploy, no reprinting needed — every code, old and new, picks it up
automatically.
