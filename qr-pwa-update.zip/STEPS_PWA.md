# PWA Update - Deploy Steps

Only these files changed/added (you already have the rest from before):
- client-insights/index.html   (redesigned, mobile-first)
- client-insights/login.html   (added PWA meta tags)
- client-insights/manifest.json  (NEW)
- client-insights/service-worker.js  (NEW)
- client-insights/icon-192.png  (NEW)
- client-insights/icon-512.png  (NEW)
- functions/client-insights/_middleware.js  (updated - allows PWA assets through)

## Steps
1. Copy these files into the matching folders in your repo (overwrite where filenames match).
2. git add client-insights/ functions/client-insights/_middleware.js
3. git commit -m "Make client dashboard installable as a mobile app (PWA)"
4. git push
5. Wait for deploy, confirm Success.
6. On your PHONE (not desktop - install prompts are mobile-specific):
   - Visit https://www.tinubudelivers.com.ng/client-insights/ in Chrome (Android) or Safari (iPhone)
   - Log in with the client dashboard password
   - Android/Chrome: look for "Add to Home Screen" or an install icon in the address bar
   - iPhone/Safari: tap the Share icon -> "Add to Home Screen"
7. Confirm it now shows an app icon on your home screen, and tapping it opens
   full-screen without browser address bars.
