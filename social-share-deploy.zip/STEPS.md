# Social Share Infographic - Deploy Steps

## Files
- delivers-index.html  -> copy to delivers/index.html (overwrite)
- assets/president-photo.jpg -> copy to assets/president-photo.jpg (new folder)

## Steps
1. cp delivers-index.html delivers/index.html
2. mkdir -p assets
3. cp assets/president-photo.jpg assets/president-photo.jpg
4. git add delivers/index.html assets/president-photo.jpg
5. git commit -m "Branded shareable infographic: real design, live data, working share buttons"
6. git push
7. Wait for deploy, confirm Success.

## Test
- Visit https://www.tinubudelivers.com.ng/delivers/
- Pick any sector or state, generate its report
- Scroll to the share buttons, click "Download"
- Confirm the downloaded PNG matches the branded design (header, photo,
  hero stat box, 6 tiles, key achievements, footer) - not a plain
  screenshot of the page.
- Try WhatsApp/Twitter/Facebook buttons too if on a device that supports
  the Web Share API (mobile) - desktop will open share-intent URLs instead.
