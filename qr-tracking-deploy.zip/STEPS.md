# QR Tracking + Client Dashboard - Deploy Steps

## 1. Set the client dashboard password
Cloudflare Pages dashboard -> your project -> Settings -> Environment variables (Production)
Add: CLIENT_DASHBOARD_PASSWORD = <choose a password, share it with the client separately from the admin password>

## 2. Copy files into your repo
- functions/track-qr.js
- functions/qr-stats.js
- functions/client-login.js
- functions/client-insights/_middleware.js
- qr-banner.js  (goes at repo root, alongside delivers/ and admin/)
- client-insights/login.html
- client-insights/index.html

## 3. Update how you generate QR codes going forward
Every new QR code should encode:
  https://www.tinubudelivers.com.ng/track-qr?tag=<short-label>&dest=/delivers/
Example: https://www.tinubudelivers.com.ng/track-qr?tag=lagos-rally-2026&dest=/delivers/
The tag is whatever short label you want (state name, event name, agent ID) -
it's what shows up in both dashboards to tell scans apart.

## 4. Push and deploy
git add functions/track-qr.js functions/qr-stats.js functions/client-login.js functions/client-insights/_middleware.js qr-banner.js client-insights/
git commit -m "Add QR tracking, client insights dashboard, 40m usage alert"
git push

## 5. Test
- Visit https://www.tinubudelivers.com.ng/track-qr?tag=test1&dest=/delivers/
  Confirm it redirects you to /delivers/ correctly.
- Visit https://www.tinubudelivers.com.ng/qr-stats
  Confirm it shows JSON with total:1 (or higher) and a "test1" entry.
- Visit https://www.tinubudelivers.com.ng/client-insights/
  Confirm it redirects to login, then shows the dashboard after entering
  the CLIENT_DASHBOARD_PASSWORD you set in step 1.

## Note on the admin panel integration
This does NOT yet add the banner to your existing admin/index.html - that
needs the actual file pasted in so it can be integrated precisely rather than
guessed at. Once you paste admin/index.html, I'll give you the exact small
addition needed (just embedding qr-banner.js, same as the client dashboard).
