// ── Tinubu Delivers — Cloudflare Pages Function with KV Caching ──────────────
// Cache: PERMANENT — no expiry. Content served indefinitely until manual refresh.
// KV namespace binding name: TD_CACHE (set in Cloudflare dashboard)
// This reduces API calls from 1-per-user to 1-per-sector/state-per-day

// Cache is permanent — no TTL. Refresh manually via /seed when needed.

export async function onRequestPost(context) {
  const apiKey = context.env.ANTHROPIC_API_KEY;
  const kv     = context.env.TD_CACHE; // KV namespace binding

  if (!apiKey) {
    return new Response(JSON.stringify({error:'API key not configured'}), {
      status:500, headers:{'Content-Type':'application/json'}
    });
  }

  let body;
  try {
    body = await context.request.json();
  } catch {
    return new Response(JSON.stringify({error:'Invalid request body'}), {
      status:400, headers:{'Content-Type':'application/json'}
    });
  }

  // ── BUILD CACHE KEY FROM THE PROMPT ────────────────────────────────────────
  // Extract sector/state name from the prompt to use as cache key
  let cacheKey = null;
  if (kv && body.messages && body.messages[0]) {
    const prompt = body.messages[0].content || '';

    // Detect sector
    const sectorMatch = prompt.match(/in the sector:\s*"([^"]+)"/i);
    if (sectorMatch) {
      cacheKey = 'sector:' + sectorMatch[1].toLowerCase().replace(/\s+/g,'-');
    }

    // Detect state
    const stateMatch = prompt.match(/specifically in (\w[\w\s]+) State,\s*Nigeria/i);
    if (stateMatch) {
      cacheKey = 'state:' + stateMatch[1].toLowerCase().replace(/\s+/g,'-');
    }
  }

  // ── CHECK CACHE FIRST ──────────────────────────────────────────────────────
  if (kv && cacheKey) {
    try {
      const cached = await kv.get(cacheKey, {type:'text'});
      if (cached) {
        // Return cached response — zero API cost
        return new Response(cached, {
          status:200,
          headers:{
            'Content-Type':'application/json',
            'Access-Control-Allow-Origin':'*',
            'X-Cache':'HIT',
            'X-Cache-Key': cacheKey
          }
        });
      }
    } catch(e) {
      // KV read failed — fall through to API call
      console.error('KV read error:', e);
    }
  }

  // ── NO LIVE GENERATION — verified-content only ─────────────────────────────
  // This platform now serves ONLY pre-verified, source-checked content from TD_CACHE.
  // (Previously this block called the Anthropic API with a prompt that instructed
  // "ALL content must be POSITIVE" and to never show declines — that generated
  // unverified, one-sided content on every cache miss. Removed entirely.)
  // If a key isn't cached, return an honest "not yet available" card instead.
  const fallback = {
    content: [{
      type: 'text',
      text: JSON.stringify({
        sector: cacheKey ? cacheKey.split(':')[1].replace(/-/g,' ') : 'this selection',
        headline: 'Verified data not yet available for this selection',
        stats: [],
        achievements: [],
        other_achievements: [],
        progress: [],
        comparison: [],
        quote: 'This selection has not yet been added to the verified dataset. Check back soon.',
        source: 'Tinubu Delivers'
      })
    }]
  };
  const responseText = JSON.stringify(fallback);

  return new Response(responseText, {
    status: 200,
    headers:{
      'Content-Type':'application/json',
      'Access-Control-Allow-Origin':'*',
      'X-Cache':'MISS-NOGEN',
      'X-Cache-Key': cacheKey || 'none'
    }
  });
}

export async function onRequestOptions() {
  return new Response(null, {
    headers:{
      'Access-Control-Allow-Origin':'*',
      'Access-Control-Allow-Methods':'POST, OPTIONS',
      'Access-Control-Allow-Headers':'Content-Type'
    }
  });
}
