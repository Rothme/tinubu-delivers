# IMPORTANT: your seed.js and seed-payload-v2.json were deleted after last successful seed.
# You need to recreate BOTH before this works - do not skip straight to just copying the data file.

1. Upload this zip to Codespaces, then:
   unzip tinubu-delivers-deploy-v7.zip -d /tmp/deploy

2. Recreate functions/seed.js (paste this exact block in the terminal):
   cat > functions/seed.js << 'SEEDEOF'
   import ALL_ENTRIES from "./seed-payload-v2.json";
   export async function onRequestGet(context) {
     const { request, env } = context;
     const url = new URL(request.url);
     const providedKey = url.searchParams.get("key");
     if (!env.SEED_KEY || providedKey !== env.SEED_KEY) {
       return new Response(JSON.stringify({ error: "Unauthorized. Pass ?key=<SEED_KEY>." }), { status: 401, headers: { "content-type": "application/json" } });
     }
     const results = [];
     for (const [cacheKey, entry] of Object.entries(ALL_ENTRIES)) {
       try { await env.TD_CACHE.put(cacheKey, JSON.stringify(entry)); results.push({ key: cacheKey, status: "ok" }); }
       catch (err) { results.push({ key: cacheKey, status: "error", message: String(err) }); }
     }
     const failed = results.filter(r => r.status !== "ok");
     return new Response(JSON.stringify({ seeded: results.length, failed: failed.length, failures: failed, reminder: "Delete functions/seed.js and functions/seed-payload-v2.json now, then commit and push." }, null, 2), { headers: { "content-type": "application/json" } });
   }
   SEEDEOF

3. Copy the new data file:
   cp /tmp/deploy/tinubu-delivers-deploy-v7/functions/seed-payload-v2.json functions/seed-payload-v2.json

4. git add functions/seed.js functions/seed-payload-v2.json
   git commit -m "Add infrastructure km rollup, DB1 merge, South-East projects"
   git push

5. Wait for deploy, confirm "Success" in Cloudflare Deployments tab.

6. Visit https://tinubu-delivers.pages.dev/seed?key=YOUR_SEED_KEY

7. Confirm "seeded": 49, "failed": 0

8. git rm functions/seed.js functions/seed-payload-v2.json
   git commit -m "cleanup"
   git push
