# Login redesign + self-service password - Deploy Steps

## New/changed files
- client-insights/login.html          (photo background, forced-reset handling)
- client-insights/index.html          (change-password panel, logout button)
- client-insights/login-bg-source.jpg (NEW - the background photo)
- functions/client-login.js           (now checks KV password first, env var as bootstrap only)
- functions/client-change-password.js (NEW)
- functions/client-logout.js          (NEW)
- functions/admin-reset-client-password.js (NEW)
- functions/_shared/password.js       (NEW - shared hashing helper)
- functions/client-insights/_middleware.js (updated allowlist)

## 1. Set the admin reset key
Cloudflare Pages -> your project -> Settings -> Environment variables (Production)
Add: ADMIN_RESET_KEY = <choose a private value, different from SEED_KEY>

## 2. Copy all files into matching folders in your repo

## 3. Push
git add client-insights/ functions/
git commit -m "Client dashboard: photo login background, self-service password change, admin reset"
git push

## 4. Test the normal flow
- Visit https://www.tinubudelivers.com.ng/client-insights/
- Confirm the login page now shows the photo background
- Log in with your existing CLIENT_DASHBOARD_PASSWORD (or whatever you already set)
- Tap "Account" (top right) -> change password -> confirm it saves
- Log out, log back in with the NEW password to confirm it took effect

## 5. Test the admin-reset flow
- Visit https://www.tinubudelivers.com.ng/admin-reset-client-password?key=<ADMIN_RESET_KEY>
- Confirm it returns {"ok": true, ...}
- Go to /client-insights/ and log in using the ORIGINAL CLIENT_DASHBOARD_PASSWORD
  (the one from the very first environment variable you set, not whatever they'd
  changed it to)
- Confirm it forces you straight into the "Set a new password" screen with no
  way to dismiss it until a new password is saved
