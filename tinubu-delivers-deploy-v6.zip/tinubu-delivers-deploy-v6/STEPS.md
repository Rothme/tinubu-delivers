# Same pattern. Only functions/seed-payload-v2.json changed.

1. cp functions/seed-payload-v2.json functions/seed-payload-v2.json   (overwrite)
2. git add functions/seed-payload-v2.json
3. git commit -m "Add per-state VAT and Ecology Fund allocation data"
4. git push
5. Wait for deploy.
6. Visit https://tinubu-delivers.pages.dev/seed?key=YOUR_SEED_KEY
7. Confirm "seeded": 49, "failed": 0
8. git rm functions/seed.js functions/seed-payload-v2.json && git commit -m "cleanup" && git push
